function App() {
  return (
    <>
      <div className='bg-red-700 p-6 min-h-screen'>
        <h1 className='text-4xl text-white font-bold'>Tailwind is working!</h1>
        <p className='text-green-300 text-lg'>Big sales data dashboard!</p>
      </div>
    </>
  );
}

export default App;
