import React from "react";

export default function ChartMonthly(){

    return(
        <></>
    )
}