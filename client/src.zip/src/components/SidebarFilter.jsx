import React from "react";

export default function SidebarFilters({ filters, setFilters }) {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <aside className="w-64 bg-white shadow-md p-4 hidden md:block">
      <h2 className="text-lg font-semibold text-green-800 mb-4">Filters</h2>

      {/* Gender Filter */}
      <div className="mb-4">
        <label htmlFor="gender" className="block text-green-700 font-medium mb-1">
          Gender
        </label>
        <select
          id="gender"
          name="gender"
          value={filters.gender}
          onChange={handleChange}
          className="w-full border border-green-300 rounded px-3 py-2 focus:outline-none focus:ring focus:border-green-500"
        >
          <option value="All">All</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
        </select>
      </div>

      {/* Payment Method Filter */}
      <div className="mb-4">
        <label htmlFor="payment_method" className="block text-green-700 font-medium mb-1">
          Payment Method
        </label>
        <select
          id="payment_method"
          name="payment_method"
          value={filters.payment_method}
          onChange={handleChange}
          className="w-full border border-green-300 rounded px-3 py-2 focus:outline-none focus:ring focus:border-green-500"
        >
          <option value="All">All</option>
          <option value="Credit Card">Credit Card</option>
          <option value="Cash">Cash</option>
          <option value="M-Pesa">M-Pesa</option>
          <option value="E-Wallet">E-Wallet</option>
        </select>
      </div>

      {/* Product Category Filter */}
      <div className="mb-4">
        <label htmlFor="category" className="block text-green-700 font-medium mb-1">
          Product Category
        </label>
        <select
          id="category"
          name="category"
          value={filters.category}
          onChange={handleChange}
          className="w-full border border-green-300 rounded px-3 py-2 focus:outline-none focus:ring focus:border-green-500"
        >
          <option value="All">All</option>
          <option value="Electronics">Electronics</option>
          <option value="Clothing">Clothing</option>
          <option value="Home">Home</option>
          <option value="Health">Health</option>
        </select>
      </div>
    </aside>
  );
}
