import React from "react";

export default function ChartByPayment(){

    return(
        <></>
    )
}