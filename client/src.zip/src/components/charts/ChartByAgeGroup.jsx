import React from "react";

export default function ChartByAgeGroup(){

    return(
        <></>
    )
}